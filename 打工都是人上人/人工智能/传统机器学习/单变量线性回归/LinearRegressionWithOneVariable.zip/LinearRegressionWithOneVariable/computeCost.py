import numpy as np



def compute_cost(X, y, theta):

    m = y.size

    cost = 0

    cost = 1/(2*m)*np.sum(np.power(((X.dot(theta.T)) - y), 2));

    return cost